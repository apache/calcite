public class SetVendor {
public static void premain(String args) {
	System.setProperty("java.vendor", "International Business Machines Corporation");
}
}

